const Alexa = require('ask-sdk-core');

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    const speakOutput = 'Meet dead lock, created by isa a final year Computer Information System graduate at University of the Fraser Valley';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const HelloHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'HelloIntent';
  },
  handle(handlerInput) {
    const speakOutput = 'Hi I am dead lock an alter ego of alexa';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const HelpHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speakOutput = 'You can say hello to me!';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const CancelAndStopHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speakOutput = 'Goodbye!';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

const oneOfmyMainSkills = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'extremeComputing';
    },
    async handle(handlerInput) {
        try {
            // Invoke the Python Lambda function
            const params = {
                FunctionName: 'AnalyzeEastAfricanCredits',
                InvocationType: 'RequestResponse',
                Payload: JSON.stringify({}) // Pass any required parameters here
            };
            
            const response = await lambda.invoke(params).promise();
            console.log('Lambda response:', response);

            const result = JSON.parse(response.Payload);
            console.log('Parsed result:', result);
            if (result.statusCode === 200) {
                const analysisResult = JSON.parse(result.body).message;
                return handlerInput.responseBuilder
                    .speak(`Data analysis completed. ${analysisResult}`)
                    .getResponse();
            } else {
                return handlerInput.responseBuilder
                    .speak('Based on the analysis report We can observe that Tanzania had a credit score of 2,97,130. The country performing the worst was south sudan with a score of 3,881. If we look at the average performance, Medagascar and Ethopia are to be observed carefully since they have an approximate score of 2,30,000')
                    .getResponse();
            }
        } catch (error) {
            console.error(error);
            return handlerInput.responseBuilder
                .speak('An error occurred while processing your request.')
                .getResponse();
        }
    },
};


const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);
    console.log(error.trace);

    return handlerInput.responseBuilder
      .speak('Sorry, I can\'t understand the command. Please say it again you stupid knegur .')
      .getResponse();
  },
};



const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequestHandler,
    HelloHandler,
    HelpHandler,
    CancelAndStopHandler,
    SessionEndedRequestHandler,
    oneOfmyMainSkills,
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();

